<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Account;

class AccountController extends Controller
{
    //

    public function index()
    {
        $accounts = Account::orderBy('code')->get();
        return view('master.accounts', compact('accounts'));
    
    }

    public function store(Request $request)
    {
        Account::create($request->all());
        return redirect()->back()->with('success', 'Akun berhasil ditambah!');

      
    }
}
