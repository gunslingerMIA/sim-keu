<?php

namespace App\Http\Controllers;

use App\Models\Program;
use Illuminate\Http\Request;

class MasterProgramController extends Controller
{
    public function index()
    {
        // Narik Program beserta Kegiatan dan Sub-Kegiatannya (Eager Loading)
        $programs = Program::with('activities.subActivities')->get();
        
        return view('master.programs', compact('programs'));
    }

    public function storeProgram(Request $request)
    {
        $request->validate([
            'nama_program' => 'required', 
            'kode_program' => 'required|unique:programs,kode_program'
            ], 
            [
            'kode_program.unique' => 'Kode Program sudah ada, gunakan kode lain!'
            ]);
        Program::create($request->all());
        return back()->with('success', 'Program berhasil ditambah');
    }

    public function updateProgram(Request $request, $id)
    {
        
        $request->validate([
                'nama_program' => 'required', 
                'kode_program' => 'required|unique:programs,kode_program,'.$id,
            ], 
            [
                'kode_program.unique' => 'Kode Program sudah ada, gunakan kode lain!'
        ]);
        dd($message);           

        $program = \App\Models\Program::findOrFail($id);
        $program->update($request->all());

        return back()->with('success', 'Program berhasil diperbarui!');
    }

    public function deleteProgram($id)
    {
        // cari program beserta jumlah kegiatannya
        $program = \App\Models\Program::withCount('activities')->findOrFail($id);

        //cek apakah masih ada kegiatan
        if($program->activities_count > 0){
            return back()->with('error', 'Program masih memiliki kegiatan, hapus kegiatan terlebih dahulu!');
        }
        $program->delete(); 
        return back()->with('success', 'Program berhasil dihapus');
    }

    public function deleteActivity($id)
    {
        $activity = \App\Models\Activity::withCount('subActivities')->findOrFail($id);

        if($activity->sub_activities_count > 0){
            return back()->with('error', 'Kegiatan masih memiliki sub-kegiatan, hapus sub-kegiatan terlebih dahulu!');
        }
        $activity->delete(); 
        return back()->with('success', 'Kegiatan berhasil dihapus');
    }

    public function deleteSubActivity($id)
    {
        $subActivity = \App\Models\SubActivity::findOrFail($id);
        $subActivity->delete(); 
        return back()->with('success', 'Sub-Kegiatan berhasil dihapus');
    }
    // Nanti bisa ditambah fungsi storeActivity dan storeSubActivity di sini
}