<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    //
    protected $fillable = ['code', 'name', 'type', 'initial_balance'];

    public function up(){
        Schema::create('accounts', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique(); // Contoh: 5.1.02.01.0026
                $table->string('name');           // Contoh: Belanja Bahan Cetak
                $table->enum('type', ['belanja', 'kas', 'panjar', 'pajak']); 
                $table->timestamps();
        });
    }
   
}
