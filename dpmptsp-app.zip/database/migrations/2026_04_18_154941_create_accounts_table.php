<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique(); // Contoh: 5.1.02... (Belanja) atau PJR-01 (Panjar)
            $table->string('name');           // Nama Rekening / Nama Pegawai
            
            // Kita kasih kategori supaya sistem nggak bingung
            // belanja = DPA, kas = Duit di brankas/bank, panjar = Uang muka kerja
            $table->enum('type', ['belanja', 'kas', 'panjar', 'pajak']);
            
            $table->decimal('initial_balance', 15, 2)->default(0); // Saldo awal jika ada
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};
