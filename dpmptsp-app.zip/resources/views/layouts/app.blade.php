<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <title>SIM-KEU DPMPTSP</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/core@1.4.0/dist/css/tabler.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        @import url('https://rsms.me/inter/inter.css');
        :root { --tblr-font-sans-serif: 'Inter var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; }
        
        /* Teknik Sidebar Fixed */
        .page { display: flex; flex-direction: row; height: 100vh; overflow: hidden; }
        
        .sidebar-fixed { 
            width: 250px; 
            background: #0f172a; 
            color: #cbd5e1; 
            height: 100vh; 
            overflow-y: auto; 
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
        }

        .content-area { 
            flex-grow: 1; 
            height: 100vh; 
            overflow-y: auto; 
            background: #f8fafc; 
        }

        .nav-link { color: #94a3b8; font-size: 0.875rem; padding: 10px 20px; border-radius: 6px; margin: 0 12px 4px; transition: all 0.2s; }
        .nav-link:hover { background: #1e293b; color: #f8fafc; }
        .nav-link.active { background: #3b82f6; color: white; }
        .nav-link i { margin-right: 12px; font-size: 1.1rem; }
        .menu-header { font-size: 0.7rem; text-transform: uppercase; color: #64748b; font-weight: 700; margin: 24px 24px 8px; letter-spacing: 0.05em; }
        
        /* Custom Scrollbar untuk Sidebar */
        .sidebar-fixed::-webkit-scrollbar { width: 4px; }
        .sidebar-fixed::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
        tr[aria-expanded="true"] .bi-chevron-down {
            transform: rotate(180deg);
            transition: transform 0.3s;
        }
        tr[aria-expanded="false"] .bi-chevron-down {
            transition: transform 0.3s;
        }
        /* Sidebar default untuk HP */
    @media (max-width: 991.98px) {
    .sidebar-fixed {
        position: fixed;
        left: -250px; /* Sembunyi di kiri */
        z-index: 1050;
        transition: all 0.3s;
    }
    
    .sidebar-fixed.show {
        left: 0; /* Muncul pas diklik */
    }

    /* Overlay biar pas sidebar buka, konten belakangnya jadi gelap */
    .sidebar-backdrop {
        display: none;
        position: fixed;
        top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(0,0,0,0.5);
        z-index: 1040;
    }
    .sidebar-backdrop.show { display: block; }
    }

    /* Tombol Hamburger */
    .mobile-nav-toggle {
        display: none;
    }
    @media (max-width: 991.98px) {
        .mobile-nav-toggle { display: block; }
    }
    </style>
</head>
<body>
    <div class="page">
        <aside class="sidebar-fixed shadow border-end border-dark">
            <div class="p-4 text-center">
                <div class="avatar avatar-md bg-primary-lt mb-2">
                    <i class="bi bi-bank text-white"></i>
                </div>
                <h6 class="text-white fw-bold mb-0">SIM-KEU DPMPTSP</h6>
                <small class="text-muted">TA {{ session('tahun_anggaran', '2026') }}</small>
            </div>

            <div class="mt-2">
                <a class="nav-link {{ request()->is('dashboard') ? 'active' : '' }}" href="/dashboard">
                    <i class="bi bi-grid-1x2-fill"></i> Dashboard
                </a>

                <div class="menu-header">Data Master</div>
                <a href="/programs" class="nav-link {{ request()->is('programs') ? 'active' : '' }} d-flex justify-content-between align-items-center" >
                    <span><i class="bi bi-diagram-3"></i> Program Kegiatan</span>
                </a>
                <a href="/accounts" class="nav-link {{ request()->is('accounts') ? 'active' : '' }}  d-flex justify-content-between align-items-center" >
                    <span><i class="bi bi-collection"></i>Akun</span>
                </a>
                

                <div class="menu-header">Transaksi</div>
                <a class="nav-link {{ request()->is('transactions')  ? 'active' : '' }}  d-flex justify-content-between align-items-center" href="/transactions">
                    <span><i class="bi bi-pencil-square"></i>Jurnal</span>
                </a>
                

                <div class="menu-header">Pelaporan</div>
                <a class="nav-link d-flex justify-content-between align-items-center" data-bs-toggle="collapse" href="#laporanSub">
                    <span><i class="bi bi-chevron-down small"></i></i> Laporan</span>
                    
                </a>
                <div class="collapse {{ request()->is('reports*') ? 'show' : '' }}" id="laporanSub">
                    <a href="/reports/lra-ringkas" class="nav-link ps-5 small">LRA</a>
                    <a href="/reports/neraca" class="nav-link ps-5 small">Neraca Saldo</a>
                    <a href="" class="nav-link ps-5 small">Buku Besar</a>
                </div>
            </div>
            
            <div class="mt-auto p-3">
                <div class="card bg-dark border-0">
                    <div class="card-body p-2 text-center">
                        <small class="text-secondary d-block">User: Admin Renval</small>
                    </div>
                </div>
            </div>
        </aside>

        <main class="content-area">
            <div id="sidebarBackdrop" class="sidebar-backdrop" onclick="toggleSidebar()"></div>

            <header class="navbar navbar-expand-md navbar-light bg-white border-bottom px-4 shadow-sm">
                <div class="container-xl">
                    <button class="navbar-toggler mobile-nav-toggle me-2" type="button" onclick="toggleSidebar()">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <h2 class="navbar-brand text-dark fw-bold mb-0">SIM-KEU</h2>
                    
                    <div class="navbar-nav flex-row order-md-last">
                        <div class="nav-item">
                            <span class="badge bg-blue-lt">TA {{ session('tahun_anggaran', '2026') }}</span>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="page-content p-4">
                @yield('content')
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tabler/core@1.4.0/dist/js/tabler.min.js"></script>

    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        @if(session('success'))
            Toast.fire({
                icon: 'success',
                title: "{{ session('success') }}"
            });
        @endif

        @if(session('error'))
            Swal.fire({
                icon: 'error',
                title: 'Waduh...',
                text: "{{ session('error') }}",
                confirmButtonColor: '#3b82f6',
            });
        @endif

        @if($errors->any())
            Swal.fire({
                icon: 'error',
                title: 'Input Tidak Valid',
                html: `
                    <ul style="text-align: left;">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                `,
                confirmButtonColor: '#3b82f6',
            });
        @endif

        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar-fixed');
            const backdrop = document.getElementById('sidebarBackdrop');
            
            sidebar.classList.toggle('show');
            backdrop.classList.toggle('show');
        }

        // Biar pas menu diklik di HP, sidebarnya nutup otomatis
        document.querySelectorAll('.sidebar-fixed .nav-link').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    toggleSidebar();
                }
            });
        });
    </script>
</body>
</body>
</html>