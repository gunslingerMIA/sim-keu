

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h3 class="card-title">Tambah Rekening Master</h3>
            </div>
            <div class="card-body">
                <form action="/accounts" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Tipe Akun</label>
                        <select name="type" class="form-select">
                            <option value="belanja">Belanja (DPA)</option>
                            <option value="kas">Kas (Bendahara)</option>
                            <option value="panjar">Panjar (Pegawai)</option>
                            <option value="pajak">Pajak (Potongan)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kode Rekening</label>
                        <input type="text" name="code" class="form-control" placeholder="5.1.02.xx..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Akun/Rekening</label>
                        <input type="text" name="name" class="form-control" placeholder="Contoh: Belanja Alat Tulis Kantor" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-plus-circle me-2"></i> Simpan Ke Master
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header">
                <h3 class="card-title">Database Master Rekening</h3>
            </div>
            <div class="table-responsive">
                <table class="table table-vcenter card-table table-striped">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Rekening</th>
                            <th>Tipe</th>
                            <th class="w-1"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><span class="badge bg-blue-lt"><?php echo e($acc->code); ?></span></td>
                            <td class="text-secondary"><?php echo e($acc->name); ?></td>
                            <td>
                                <?php if($acc->type == 'belanja'): ?> <span class="badge bg-green">Belanja</span>
                                <?php elseif($acc->type == 'panjar'): ?> <span class="badge bg-yellow">Panjar</span>
                                <?php else: ?> <span class="badge bg-azure"><?php echo e($acc->type); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="#" class="btn btn-sm btn-ghost-danger">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\App\dpmptsp-app\resources\views/master/accounts.blade.php ENDPATH**/ ?>