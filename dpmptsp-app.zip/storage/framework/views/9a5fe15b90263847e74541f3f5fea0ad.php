

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white"><h6 class="mb-0">Input Pagu DPA</h6></div>
            <div class="card-body">
                <form action="/accounts" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label>Sub-Kegiatan</label>
                        <select name="sub_activity_id" class="form-control" required>
                            <?php $__currentLoopData = $subActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->kode_sub_kegiatan); ?> - <?php echo e($sub->nama_sub_kegiatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Kode Rekening</label>
                        <input type="text" name="code" class="form-control" placeholder="5.1.02.xxx" required>
                    </div>
                    <div class="mb-3">
                        <label>Nama Rekening / Akun</label>
                        <input type="text" name="name" class="form-control" placeholder="Contoh: Belanja Alat Tulis Kantor" required>
                    </div>
                    <div class="mb-3">
                        <label>Tipe Akun</label>
                        <select name="type" class="form-control">
                            <option value="belanja">Belanja (DPA)</option>
                            <option value="kas">Kas (Bendahara)</option>
                            <option value="panjar">Panjar (Pegawai)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Nilai Pagu (Rp)</label>
                        <input type="number" name="amount" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Simpan Pagu</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white"><h6 class="mb-0">Daftar Alokasi Anggaran TA <?php echo e(session('tahun_anggaran')); ?></h6></div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Sub-Kegiatan</th>
                            <th>Rekening</th>
                            <th>Pagu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><small><?php echo e($b->subActivity->nama_sub_kegiatan); ?></small></td>
                            <td><?php echo e($b->account->code); ?></td>
                            <td class="text-end">Rp <?php echo e(number_format($b->amount, 0, ',', '.')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\App\dpmptsp-app\resources\views/accounts/index.blade.php ENDPATH**/ ?>