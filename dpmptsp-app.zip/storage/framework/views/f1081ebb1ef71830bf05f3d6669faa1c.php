

<?php $__env->startSection('content'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Jika ada error validasi di session
        <?php if($errors->any()): ?>
            // Tentukan modal mana yang harus dibuka (tambah atau edit)
            // Kita cek jika ada data 'old' untuk menentukan konteksnya
            const isEdit = "<?php echo e(old('_method')); ?>" === "PUT";
            const modalId = isEdit ? 'modal-edit-program' : 'modal-program';
            
            const modalEl = document.getElementById(modalId);
            if (modalEl && window.bootstrap) {
                const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
                modal.show();
            }
        <?php endif; ?>
    });
</script>
<div class="row mb-3 align-items-center">
    <div class="col">
        <h3 class="page-title text-primary">Cascading DPMPTSP</h3>
    </div>
    <div class="col-auto ms-auto">
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#modal-program">
            <i class="bi bi-plus-lg me-2"></i> Tambah Program Baru
        </button>
    </div>
</div>
<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-vcenter card-table">
            <thead>
                <tr>
                    <th width="20%">Kode</th>
                    <th>Uraian Struktur</th>
                    <th class="w-1"></th>
                </tr>
            </thead>
            <tbody id="accordionDPA">
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-primary-lt" style="cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#prog-<?php echo e($p->id); ?>">
                    <td class="fw-bold text-primary"><?php echo e($p->kode_program); ?></td>
                    <td class="fw-bold">
                        <i class="bi bi-folder2-open me-2"></i> <?php echo e($p->nama_program); ?>

                    </td>
                    <td class="text-end pe-3">
                        <div class="btn-group shadow-sm">
                            <button class="btn btn-sm btn-white text-primary" title="Tambah Kegiatan" 
                                    data-bs-toggle="modal" data-bs-target="#modal-kegiatan"
                                    onclick="prepareKegiatan(<?php echo e($p->id); ?>); event.stopPropagation();">
                                <i class="bi bi-plus-circle"></i>
                            </button>
                            
                            <button class="btn btn-sm btn-white text-warning" data-bs-toggle="modal" data-bs-target="#modal-edit-program" title="Edit Program" 
                                    onclick="event.stopPropagation(); editProgram(<?php echo e(json_encode($p)); ?>);">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            
                            <button class="btn btn-sm btn-white text-danger" title="Hapus Program" 
                                    onclick="event.stopPropagation(); deleteProgram(<?php echo e($p->id); ?>, <?php echo e($p->activities->count()); ?>)">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </div>
                    </td>
                </tr>

                <tr class="collapse" id="prog-<?php echo e($p->id); ?>" data-bs-parent="#accordionDPA">
                    <td colspan="3" class="p-0">
                        <table class="table table-vcenter mb-0 bg-white">
                            <tbody id="group-keg-<?php echo e($p->id); ?>">
                                <?php $__currentLoopData = $p->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-light" 
                                    style="cursor: pointer;" 
                                    data-bs-toggle="collapse" 
                                    data-bs-target="#keg-<?php echo e($a->id); ?>" 
                                    aria-expanded="false">
                                    <td width="20%" class="ps-4 text-muted small"><?php echo e($a->kode_kegiatan); ?></td>
                                    <td class="ps-4">
                                        <i class="bi bi-arrow-return-right me-2 text-secondary"></i> <?php echo e($a->nama_kegiatan); ?>

                                    </td>
                                    <td class="text-end pe-3">
                                        <div class="btn-group shadow-sm">
                                            <button class="btn btn-sm btn-white text-primary" title="Tambah Sub Kegiatan" 
                                                    data-bs-toggle="modal" data-bs-target="#modal-sub-kegiatan"
                                                    onclick="">
                                                <i class="bi bi-plus-circle"></i>
                                            </button>
                                            
                                            <button class="btn btn-sm btn-white text-warning" title="Edit Program" 
                                                    onclick="">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                            
                                            <button class="btn btn-sm btn-white text-danger" title="Hapus Program" 
                                                    onclick="">
                                                <i class="bi bi-trash3"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <tr class="collapse" id="keg-<?php echo e($a->id); ?>" data-bs-parent="#group-keg-<?php echo e($p->id); ?>">
                                    <td colspan="3" class="p-0">
                                        <table class="table table-vcenter mb-0 bg-white">
                                            <?php $__currentLoopData = $a->subActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td width="20%" class="ps-5 text-secondary small"><?php echo e($s->kode_sub_kegiatan); ?></td>
                                                <td class="ps-5 small text-secondary">
                                                    <i class="bi bi-dot me-1"></i> <?php echo e($s->nama_sub_kegiatan); ?>

                                                </td>
                                                <td class="text-end pe-3">
                                                    <button class="btn btn-sm btn-ghost-danger">Hapus</button>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>



<div class="modal modal-blur fade" id="modal-program" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="/programs/store" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Program Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Kode Program</label>
                        <input type="text" name="kode_program" class="form-control" placeholder="Contoh: 2.18.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Program</label>
                        <textarea name="nama_program" class="form-control" rows="3" placeholder="Masukkan nama program sesuai DPA..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link link-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" onclick="">Simpan Program</button>
                </div>
            </form>
        </div>
    </div>
</div>



<div class="modal modal-blur fade" id="modal-edit-program" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="" method="POST" id="form-edit-program">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Program</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Kode Program</label>
                        <input type="text" name="kode_program" id="edit_kode_program" class="form-control" required>
                        <?php $__errorArgs = ['kode_program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Program</label>
                        <textarea name="nama_program" id="edit_nama_program" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link link-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>



<div class="modal modal-blur fade" id="modal-kegiatan" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="/programs/kegiatan/store" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="program_id" id="modal_program">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Kegiatan Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Kode Kegiatan</label>
                        <input type="text" name="kode_kegiatan" class="form-control" placeholder="Contoh: 2.18.01.2.01">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Kegiatan</label>
                        <textarea name="nama_kegiatan" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link link-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Kegiatan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>

    //fungsi edit program, menerima parameter data program lengkap untuk diisi ke form

    function editProgram(program) {
        // 1. Set URL action form agar mengarah ke ID yang benar
        document.getElementById('form-edit-program').action = '/programs/update/' + program.id;

        // 2. Isi value input modal dengan data program
        document.getElementById('edit_kode_program').value = program.kode_program;
        document.getElementById('edit_nama_program').value = program.nama_program;

        
    }

    function prepareKegiatan(programId) {
        // Cukup isi ID-nya saja, modal akan dibuka otomatis oleh data-bs-target
        document.getElementById('modal_program_id').value = programId;
    }

    function prepareSubKegiatan(kegiatanId) {
        document.getElementById('modal_kegiatan_id').value = kegiatanId;
    }

    // Jika ingin tetap pakai cara manual, gunakan pengecekan ini:
    function showModalKegiatan(programId) {
        document.getElementById('modal_program_id').value = programId;
        
        // Gunakan bootstrap global dari window
        var modalEl = document.getElementById('modal-kegiatan');
        var modal = bootstrap.Modal.getOrCreateInstance(modalEl); 
        modal.show();
    }

    function deleteProgram(id, childCount) {
        if(childCount > 0) {
            Swal.fire({
                icon: 'error',
                title: 'Akses Ditolak',
                text: 'Program ini masih memiliki ' + childCount + ' Kegiatan. Hapus semua kegiatan di bawahnya terlebih dahulu.',
                confirmButtonColor: '#3b82f6'
            });
            return;
        }   
        
        Swal.fire({
            title: 'Yakin mau hapus?',
            text: "Data yang dihapus tidak bisa dikembalikan loh!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus saja!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kita arahkan ke route delete
                window.location.href = '/programs/delete/' + id;
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\App\dpmptsp-app\resources\views/master/programs.blade.php ENDPATH**/ ?>